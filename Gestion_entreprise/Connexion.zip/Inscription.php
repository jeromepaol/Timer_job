 

    

<form method="post" action="Envoi_email.php">
    
    <input type="text" name="email" placeholder="Email">
    <input type="text" name="mdp" placeholder="Mot de passe">
    
    <button type="submit">Inscription</button>

</form>
