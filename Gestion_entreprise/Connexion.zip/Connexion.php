<h1>Connexion</h1>

<form>
<input type="text" placeholder="Adresse Mail">
<input type="text" placeholder="Votre mot de passe">

</form>