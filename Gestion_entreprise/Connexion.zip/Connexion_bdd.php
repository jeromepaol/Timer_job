<?php 
    $bdd = new PDO('mysql:host=localhost;dbname=gestion-entreprise;charset=utf8', 'root' , '');
?>